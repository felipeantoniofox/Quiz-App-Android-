import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, TouchableOpacity, Alert } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router'; 
import { getQuizData } from '../../__utils/database'; 

// Função auxiliar para embaralhar ás alternativas das perguntas
const shuffleArray = (array) => {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
};

export default function GameScreen() {
    
    // 1. Obter parâmetros da navegação
    const params = useLocalSearchParams();
    
    const temaId = params.temaId ? parseInt(params.temaId) : null; 
    const temaNome = params.temaNome;
    const quantidade = params.quantidade ? parseInt(params.quantidade) : 0;
    
    const quizKey = params.quizKey; 
    
    // 2. Estados
    const [questions, setQuestions] = useState([]);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    const [score, setScore] = useState(0);
    const [isQuizFinished, setIsQuizFinished] = useState(false);
    const [optionsShuffled, setOptionsShuffled] = useState([]);

    // 3. Efeito para carregar as perguntas do banco de dados 
    useEffect(() => {
        const loadQuestions = async () => {
            
            
            setIsLoading(true); 
            setScore(0);
            setCurrentQuestionIndex(0);
            setIsQuizFinished(false);
            setQuestions([]); 
            

            if (!temaId || quantidade === 0) {
                Alert.alert("Erro", "Não foi possível iniciar o quiz: parâmetros ausentes.");
                setIsLoading(false);
                return;
            }

            try {
                
                const data = await getQuizData(temaId, quantidade);
                
                if (data.length > 0) {
                    setQuestions(data);
                } else {
                     Alert.alert("Atenção", "Nenhuma pergunta foi carregada para este quiz.");
                }
            } catch (error) {
                console.error("Erro ao carregar perguntas:", error);
                 Alert.alert("Erro", "Falha ao carregar as perguntas do banco de dados.");
            } finally {
                setIsLoading(false);
            }
        };

        loadQuestions();
    
    }, [temaId, quantidade, quizKey]); 

    // para embaralhar as opções sempre que a pergunta mudar
    useEffect(() => {
        if (questions.length > 0 && currentQuestionIndex < questions.length) {
            const currentQ = questions[currentQuestionIndex];
            // Filtra opções vazias ou nulas antes de embaralhar
            const allOptions = [
                currentQ.correta, 
                currentQ.errada1, 
                currentQ.errada2, 
                currentQ.errada3
            ].filter(option => option !== null && option !== undefined && (typeof option === 'string' ? option.trim() !== "" : true)); 
            
            setOptionsShuffled(shuffleArray(allOptions));
        }
    }, [currentQuestionIndex, questions]);


    // 4. Lógica de resposta
    const handleAnswer = (selectedOption) => {
        const currentQ = questions[currentQuestionIndex];
        
        // Verifica se acertou
        if (selectedOption === currentQ.correta) {
            setScore(prevScore => prevScore + 1);
        }

        // Move para a próxima pergunta ou finaliza o quiz
        const nextIndex = currentQuestionIndex + 1;
        if (nextIndex < questions.length) {
            setCurrentQuestionIndex(nextIndex);
        } else {
            setIsQuizFinished(true);
        }
    };
    
   
    
    
    if (isLoading) {
        return (
            <View key={quizKey} style={styles.centerContainer}>
                <ActivityIndicator size="large" color="#6c757d" />
                <Text style={styles.loadingText}>Carregando quiz de {temaNome}...</Text>
            </View>
        );
    }

    if (questions.length === 0) {
        return (
            <View key={quizKey} style={styles.centerContainer}>
                <Text style={styles.errorText}>Nenhuma pergunta encontrada para o tema "{temaNome}".</Text>
                <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                    <Text style={styles.backButtonText}>Voltar</Text>
                </TouchableOpacity>
            </View>
        );
    }

    // Se o quiz terminou, mostra o resultado
    if (isQuizFinished) {
        const totalQuestions = questions.length;
        const percentage = totalQuestions > 0 ? (score / totalQuestions) * 100 : 0;
        
        return (
            <View key={quizKey} style={styles.centerContainer}>
                <Text style={styles.resultTitle}>QUIZ FINALIZADO!</Text>
                <Text style={styles.resultText}>Você acertou {score} de {totalQuestions} perguntas.</Text>
                
                {/* EXIBIÇÃO DA PORCENTAGEM DE ACERTOS DO JOGADOR*/}
                <Text style={styles.percentageText}>
                    {percentage.toFixed(0)}% de Acerto
                </Text>

                <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                    <Text style={styles.backButtonText}>Novo Quiz</Text>
                </TouchableOpacity>
            </View>
        );
    }
    
    
    const currentQuestion = questions[currentQuestionIndex];
    
    // 5. Vai amostrar a tela do jogo
    return (
        
        <View key={quizKey} style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.headerText}>Tema: {temaNome}</Text>
                <Text style={styles.progressText}>
                    {currentQuestionIndex + 1} de {questions.length}
                </Text>
            </View>
            
            <View style={styles.questionCard}>
                <Text style={styles.questionText}>
                    {currentQuestion.pergunta} 
                </Text>
            </View>
            
            <View style={styles.optionsContainer}>
                {optionsShuffled.map((option, index) => (
                    <TouchableOpacity
                        key={index}
                        style={styles.optionButton}
                        onPress={() => handleAnswer(option)}
                    >
                        <Text style={styles.optionText}>{option}</Text>
                    </TouchableOpacity>
                ))}
            </View>

            <Text style={styles.scoreDisplay}>Acertos: {score}</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#E8EAF6', 
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#E8EAF6',
        padding: 20,
    },
    // TELA DE CARREGAMENTO E ERROS :) 
    loadingText: {
        marginTop: 10,
        fontSize: 18,
        color: '#3F51B5',
    },
    errorText: {
        fontSize: 20,
        color: 'red',
        textAlign: 'center',
        marginBottom: 20,
    },
    // TELA DE JOGO :)
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 25,
        paddingHorizontal: 5,
    },
    headerText: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#3F51B5',
    },
    progressText: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#555',
    },
    questionCard: {
        backgroundColor: 'white',
        borderRadius: 15,
        padding: 20,
        marginBottom: 30,
        minHeight: 120,
        justifyContent: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 5,
        elevation: 5,
    },
    questionText: {
        fontSize: 20,
        fontWeight: '600',
        textAlign: 'center',
        color: '#333',
    },
    optionsContainer: {
        flex: 1,
        gap: 15, 
    },
    optionButton: {
        backgroundColor: '#FFFFFF',
        paddingVertical: 18,
        paddingHorizontal: 10,
        borderRadius: 10,
        borderWidth: 2,
        borderColor: '#C5CAE9',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
        elevation: 3,
        alignItems: 'center',
    },
    optionText: {
        fontSize: 17,
        fontWeight: '500',
        color: '#3F51B5',
    },
    scoreDisplay: {
        fontSize: 22,
        fontWeight: 'bold',
        textAlign: 'center',
        marginTop: 20,
        color: '#4CAF50',
    },
    // TELA DE RESULTADO DO JOGADORRR
    resultTitle: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#3F51B5',
        marginBottom: 20,
    },
    resultText: {
        fontSize: 20,
        color: '#555',
        marginBottom: 10,
    },
    percentageText: {
        fontSize: 56, 
        fontWeight: '900',
        color: '#4CAF50', 
        marginBottom: 50,
    },
    backButton: {
        backgroundColor: '#FF9800',
        padding: 15,
        borderRadius: 10,
        marginTop: 20,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 5,
        elevation: 6,
    },
    backButtonText: {
        color: 'white',
        fontSize: 18,
        fontWeight: 'bold',
    },
});