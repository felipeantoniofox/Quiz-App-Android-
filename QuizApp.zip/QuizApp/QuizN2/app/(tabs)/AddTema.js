import React, { useState } from 'react';
import { View, TextInput, Button, Alert, Text, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import { addTema } from '../../__utils/database'; 

const AddTema = () => {
    const [nomeTema, setNomeTema] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleAddTema = async () => {
        if (nomeTema.trim() === '') {
            Alert.alert('Atenção', 'O nome do tema não pode ser vazio.');
            return;
        }

        setIsLoading(true);
        try {
            await addTema(nomeTema);
            Alert.alert('Sucesso', `Tema "${nomeTema.trim()}" cadastrado com sucesso!`);
            setNomeTema(''); 
        } catch (error) {
            console.error('Erro ao cadastrar tema:', error);
            Alert.alert('Erro', error.message || 'Falha ao cadastrar tema. Tente novamente.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <Text style={styles.title}>Cadastrar Novo Tema</Text>
            
            <TextInput
                style={styles.input}
                placeholder="Ex: História, Ciências, Matemática"
                value={nomeTema}
                onChangeText={setNomeTema}
                placeholderTextColor="#999"
                editable={!isLoading}
            />

            <TouchableOpacity
                style={[styles.button, isLoading && styles.buttonDisabled]}
                onPress={handleAddTema}
                disabled={isLoading}
            >
                <Text style={styles.buttonText}>
                    {isLoading ? 'Salvando...' : 'CADASTRAR TEMA'}
                </Text>
            </TouchableOpacity>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 30,
        color: '#333',
        textAlign: 'center',
    },
    input: {
        height: 50,
        backgroundColor: '#fff',
        borderRadius: 10,
        paddingHorizontal: 15,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#ddd',
        fontSize: 16,
    },
    button: {
        backgroundColor: '#6200ee',
        padding: 15,
        borderRadius: 10,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    buttonDisabled: {
        backgroundColor: '#b39ddb',
    },
    buttonText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
});

export default AddTema;
