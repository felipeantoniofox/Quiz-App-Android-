import React, { useState, useCallback, useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Alert, ScrollView } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useRouter } from 'expo-router';
import { useFocusEffect } from 'expo-router';
import { getTemas, countPerguntasPorTema } from '../../__utils/database';


export default function Index() {
    const router = useRouter();
    const [temas, setTemas] = useState([]);
    const [temaSelecionadoId, setTemaSelecionadoId] = useState(null);
    const [temaSelecionadoNome, setTemaSelecionadoNome] = useState(null);
    const [quantidadeDisponivel, setQuantidadeDisponivel] = useState(0);
    const [quantidadeDesejada, setQuantidadeDesejada] = useState(1);
    const [loading, setLoading] = useState(true);

    // Lista de opções de quantidade
    const opcoesQuantidade = useMemo(() => {
        return Array.from({ length: quantidadeDisponivel }, (_, i) => i + 1);
    }, [quantidadeDisponivel]);

    
    const handleTemaChange = async (temaId) => {
        const tema = temas.find(t => t.id === temaId);
        if (!tema) return;

        setTemaSelecionadoId(tema.id);
        setTemaSelecionadoNome(tema.nome);

        try {
            const count = await countPerguntasPorTema(tema.id);
            setQuantidadeDisponivel(count);
            
            setQuantidadeDesejada(count > 0 ? 1 : 0);
        } catch (error) {
            console.error("Erro ao contar perguntas:", error);
            setQuantidadeDisponivel(0);
            setQuantidadeDesejada(0);
        }
    };

    // Função para buscar os temas e configurar o estado inicial do programa 
    const fetchTemas = useCallback(async () => {
        setLoading(true);
        try {
            const temasResult = await getTemas();
            setTemas(temasResult);

            // Se houver temas, ele vai configura o primeiro como padrão ou seja o primeiro alfabeticamente
            if (temasResult.length > 0) {
                const primeiroTema = temasResult[0];
                setTemaSelecionadoId(primeiroTema.id);
                setTemaSelecionadoNome(primeiroTema.nome);

                const count = await countPerguntasPorTema(primeiroTema.id);
                setQuantidadeDisponivel(count);
                setQuantidadeDesejada(count > 0 ? 1 : 0);
            } else {
                // Se não houver temas, ele vai limpa os estados
                setTemaSelecionadoId(null);
                setTemaSelecionadoNome(null);
                setQuantidadeDisponivel(0);
                setQuantidadeDesejada(0);
            }
        } catch (error) {
            console.error("Erro ao buscar temas:", error);
            Alert.alert("Erro de DB", "Não foi possível carregar os temas.");
        } finally {
            setLoading(false);
        }
    }, []); 

   
    useFocusEffect(
        useCallback(() => {
            fetchTemas();
            return () => {}; 
        }, [fetchTemas])
    );

    const quizKeyRef = React.useRef(0);

    const handleStartQuiz = () => {
        if (!temaSelecionadoId || quantidadeDesejada === 0) {
            Alert.alert("Atenção", "Selecione um tema com perguntas e uma quantidade válida.");
            return;
        }

        quizKeyRef.current += 1;
        const newQuizKey = quizKeyRef.current;

        router.push({
            pathname: 'game',
            params: {
                temaId: temaSelecionadoId,
                temaNome: temaSelecionadoNome,
                quantidade: quantidadeDesejada,
                quizKey: newQuizKey
            }
        });
    };

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#6c757d" />
                <Text style={styles.loadingText}>Carregando temas...</Text>
            </View>
        );
    }

    const hasTemas = temas.length > 0;
    const isQuizReady = hasTemas && quantidadeDesejada > 0;

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <Text style={styles.title}>Sistema de QUIZ</Text>

            {/* SELETOR DE TEMA */}
            <Text style={styles.label}>1. Selecione o Tema ({quantidadeDisponivel} Perguntas)</Text>
            <View style={styles.pickerContainer}>
                {hasTemas ? (
                    <Picker
                        selectedValue={temaSelecionadoId}
                        onValueChange={(itemValue) => handleTemaChange(itemValue)}
                        style={styles.picker}
                        itemStyle={styles.pickerItem}
                    >
                        {temas.map((tema) => (
                            <Picker.Item key={tema.id} label={tema.nome} value={tema.id} />
                        ))}
                    </Picker>
                ) : (
                    <Text style={styles.noDataText}>Nenhum tema cadastrado.</Text>
                )}
            </View>

            {/* SELETOR DE QUANTIDADE */}
            <Text style={styles.label}>2. Quantidade de Perguntas</Text>
            <View style={styles.pickerContainer}>
                {isQuizReady ? (
                    <Picker
                        selectedValue={quantidadeDesejada}
                        onValueChange={(itemValue) => setQuantidadeDesejada(itemValue)}
                        style={styles.picker}
                        itemStyle={styles.pickerItem}
                    >
                        {opcoesQuantidade.map((num) => (
                            <Picker.Item key={num} label={`${num}`} value={num} />
                        ))}
                    </Picker>
                ) : (
                    <Text style={styles.noDataText}>
                        {hasTemas ? "Este tema não tem perguntas disponíveis." : "Selecione um tema com perguntas."}
                    </Text>
                )}
            </View>

            {/* BOTÃO INICIAR QUIZ */}
            <TouchableOpacity
                onPress={handleStartQuiz}
                disabled={!isQuizReady}
                style={[styles.startButton, !isQuizReady && styles.disabledButton]}
            >
                <Text style={styles.buttonText}>INICIAR QUIZ ({quantidadeDesejada} Perguntas)</Text>
            </TouchableOpacity>
        </ScrollView>
    );
}

// ----------------------------------------------------
// Fiat Estilos 
// ----------------------------------------------------
const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        backgroundColor: '#f8f8f8',
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#6c757d',
        marginBottom: 30,
        textAlign: 'center',
    },
    label: {
        fontSize: 16,
        fontWeight: '600',
        color: '#495057',
        marginBottom: 8,
        marginTop: 15,
    },
    pickerContainer: {
        backgroundColor: '#ffffff',
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#ced4da',
        overflow: 'hidden',
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
        elevation: 2,
    },
    picker: {
        height: 50,
        width: '100%',
        color: '#343a40',
    },
    pickerItem: {
        fontSize: 16,
    },
    noDataText: {
        padding: 15,
        textAlign: 'center',
        color: '#999999',
    },
    startButton: {
        backgroundColor: '#6c757d',
        padding: 15,
        borderRadius: 10,
        alignItems: 'center',
        marginTop: 40,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 5,
        elevation: 6,
    },
    disabledButton: {
        backgroundColor: '#adb5bd',
    },
    buttonText: {
        color: 'white',
        fontSize: 18,
        fontWeight: 'bold',
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f8f8f8',
    },
    loadingText: {
        marginTop: 10,
        color: '#6c757d',
        fontSize: 16,
    }
});