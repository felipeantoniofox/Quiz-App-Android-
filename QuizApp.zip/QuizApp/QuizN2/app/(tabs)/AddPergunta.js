import React, { useState, useCallback } from 'react';
import { View, TextInput, Button, Text, Alert, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Picker } from '@react-native-picker/picker'; 
import { useFocusEffect } from '@react-navigation/native';
import { addPergunta, addAlternativa, getTemas } from '../../__utils/database';

const NUM_ALTERNATIVES = 4;

const AddPergunta = () => {
    const [pergunta, setPergunta] = useState('');
    const [temas, setTemas] = useState([]);
    const [temaSelecionadoId, setTemaSelecionadoId] = useState(null);
    const [loadingTemas, setLoadingTemas] = useState(true);
    const [alternativas, setAlternativas] = useState(
        Array(NUM_ALTERNATIVES).fill(null).map((_, index) => ({
            id: index,
            texto: '',
            isCorreta: false,
        }))
    );

    const loadTemas = async () => {
        setLoadingTemas(true);
        try {
            const temasData = await getTemas();
            setTemas(temasData);

            if (temasData.length > 0) {
                // Vai seleciona o primeiro tema por padrão
                setTemaSelecionadoId(temasData[0].id);
            } else {
                setTemaSelecionadoId(null);
            }
        } catch (error) {
            console.error("Erro ao carregar temas:", error);
            Alert.alert("Erro", "Falha ao carregar a lista de temas.");
        } finally {
            setLoadingTemas(false);
        }
    };

    
    
    useFocusEffect(
        useCallback(() => {
            loadTemas();
            
            return () => {}; 
        }, []) 
    );

    const handleAlternativeChange = (text, index) => {
        const newAlternatives = [...alternativas];
        newAlternatives[index].texto = text;
        setAlternativas(newAlternatives);
    };

    const handleToggleCorrect = (index) => {
        const newAlternatives = alternativas.map((alt, i) => ({
            ...alt,
            
            isCorreta: i === index,
        }));
        setAlternativas(newAlternatives);
    };

    const handleSalvarPergunta = async () => {
        // Validação 1: Pergunta e Tema
        if (!pergunta.trim() || !temaSelecionadoId) {
            Alert.alert("Atenção", "Por favor, preencha a pergunta e selecione um tema.");
            return;
        }

        // Validação 2: Alternativas preenchidas e uma correta
        const preenchidas = alternativas.filter(alt => alt.texto.trim() !== "");
        const correta = alternativas.find(alt => alt.isCorreta);

        if (preenchidas.length !== NUM_ALTERNATIVES) {
            Alert.alert("Atenção", `Por favor, preencha todas as ${NUM_ALTERNATIVES} alternativas.`);
            return;
        }

        if (!correta) {
            Alert.alert("Atenção", "Por favor, marque exatamente uma alternativa como correta.");
            return;
        }

        try {
            // 1. Cadastra a Pergunta e pega o Id
            const perguntaId = await addPergunta(pergunta.trim(), temaSelecionadoId);

            // 2. Vai Cadastra as Alternativas usando o Id da Pergunta
            for (const alt of alternativas) {
                await addAlternativa(perguntaId, alt.texto.trim(), alt.isCorreta);
            }

            Alert.alert("Sucesso", "Pergunta e alternativas cadastradas!");
            
            // Limpa os estados para um novo cadastro de perguntas :)
            setPergunta('');
            setAlternativas(Array(NUM_ALTERNATIVES).fill(null).map((_, index) => ({
                id: index,
                texto: '',
                isCorreta: false,
            })));
        } catch (error) {
            Alert.alert("Erro", "Falha ao salvar a pergunta.");
            console.error(error);
        }
    };

    return (
        <ScrollView style={styles.container} contentContainerStyle={styles.content}>
            <Text style={styles.title}>Cadastro de Pergunta</Text>

            {/* SELETOR DE TEMA */}
            <Text style={styles.label}>Tema:</Text>
            {loadingTemas ? (
                <Text style={styles.pickerPlaceholder}>Carregando temas...</Text>
            ) : temas.length === 0 ? (
                <Text style={styles.pickerPlaceholder}>Nenhum tema cadastrado. Cadastre um tema primeiro.</Text>
            ) : (
                <View style={styles.pickerContainer}>
                    <Picker
                        selectedValue={temaSelecionadoId}
                        onValueChange={(itemValue) => setTemaSelecionadoId(itemValue)}
                        style={styles.picker}
                    >
                        {temas.map((tema) => (
                            <Picker.Item key={tema.id} label={tema.nome} value={tema.id} />
                        ))}
                    </Picker>
                </View>
            )}

            {/* TEXTO PARA PERGUNTA */}
            <Text style={styles.label}>Pergunta:</Text>
            <TextInput
                style={styles.input}
                placeholder="Digite o texto da pergunta"
                value={pergunta}
                onChangeText={setPergunta}
                multiline
            />

            {/* ALTERNATIVAS */}
            <Text style={styles.label}>Alternativas (Marque a Correta):</Text>
            {alternativas.map((alt, index) => (
                <View key={alt.id} style={styles.alternativeRow}>
                    <TextInput
                        style={[styles.input, styles.altInput]}
                        placeholder={`Alternativa ${index + 1}`}
                        value={alt.texto}
                        onChangeText={(text) => handleAlternativeChange(text, index)}
                    />
                    <TouchableOpacity 
                        style={[styles.checkbox, alt.isCorreta && styles.checkboxCorrect]}
                        onPress={() => handleToggleCorrect(index)}
                    >
                        <Text style={styles.checkboxText}>{alt.isCorreta ? '✓' : ''}</Text>
                    </TouchableOpacity>
                </View>
            ))}

            {/* BOTÃO SALVAR */}
            <TouchableOpacity 
                style={styles.button} 
                onPress={handleSalvarPergunta}
                disabled={!temaSelecionadoId} // Desabilita se nenhum tema estiver selecionado
            >
                <Text style={styles.buttonText}>SALVAR PERGUNTA</Text>
            </TouchableOpacity>
            
            {!temaSelecionadoId && (
                <Text style={styles.warningText}>* Cadastre um tema na aba "Add Tema" antes de continuar.</Text>
            )}
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f9f9f9',
    },
    content: {
        padding: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 25,
        color: '#333',
        textAlign: 'center',
    },
    label: {
        fontSize: 16,
        fontWeight: '600',
        marginTop: 15,
        marginBottom: 5,
        color: '#555',
    },
    input: {
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 8,
        padding: 12,
        fontSize: 16,
        minHeight: 40,
        marginBottom: 10,
    },
    // STYLE
    pickerContainer: {
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 8,
        backgroundColor: '#fff',
        marginBottom: 10,
        overflow: 'hidden',
    },
    picker: {
        height: 50,
        width: '100%',
    },
    pickerPlaceholder: {
        backgroundColor: '#eee',
        padding: 12,
        borderRadius: 8,
        color: '#999',
        textAlign: 'center',
        fontStyle: 'italic',
        marginBottom: 10,
        borderWidth: 1,
        borderColor: '#ccc',
    },
    // alternativas do fiat stilo 
    alternativeRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    altInput: {
        flex: 1,
        marginBottom: 0,
        marginRight: 10,
    },
    checkbox: {
        width: 30,
        height: 30,
        borderRadius: 15,
        borderWidth: 2,
        borderColor: '#ccc',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    checkboxCorrect: {
        backgroundColor: '#4CAF50',
        borderColor: '#4CAF50',
    },
    checkboxText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
    },
    // botão fiat stilo 
    button: {
        backgroundColor: '#6200ee',
        padding: 15,
        borderRadius: 10,
        alignItems: 'center',
        marginTop: 20,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    buttonText: {
        color: 'white',
        fontSize: 18,
        fontWeight: 'bold',
    },
    warningText: {
        marginTop: 10,
        color: 'red',
        fontSize: 14,
        textAlign: 'center',
    }
});

export default AddPergunta;
