import React from 'react';
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons'; 

export default function TabLayout() {
    return (
        <Tabs screenOptions={{ 
            tabBarActiveTintColor: '#6200ee', 
            tabBarStyle: { height: 60, paddingBottom: 5 },
            headerTitleAlign: 'center',
            headerStyle: { backgroundColor: '#f5f5f5' }
        }}>
            {/*index.js */}
            <Tabs.Screen
                name="index" 
                options={{
                    title: 'Início Quiz',
                    tabBarIcon: ({ color }) => <Ionicons name="home" size={24} color={color} />,
                }}
            />

            {/* ROTA DE CADASTRO DE PERGUNTAS */}
            <Tabs.Screen
                name="AddPergunta" 
                options={{
                    title: 'Add Pergunta',
                    tabBarIcon: ({ color }) => <Ionicons name="add-circle" size={24} color={color} />,
                }}
            />

            {/* ROTA DE CADASTRO DE TEMAS */}
            <Tabs.Screen
                name="AddTema" 
                options={{
                    title: 'Add Tema',
                    tabBarIcon: ({ color }) => <Ionicons name="bookmark" size={24} color={color} />,
                }}
            />

            
            
                {
                    <Tabs.Screen
                        name="explore" // Deve ser exatamente o nome do arquivo: explore.js
                        options={{
                            title: 'Explore',
                            tabBarIcon: ({ color }) => <Ionicons name="compass" size={24} color={color} />,
                        }}
                    />
                }
                {
                    <Tabs.Screen
                        name="game" // Deve ser exatamente o nome do arquivo: explore.js
                        options={{
                            title: 'game',
                            tabBarIcon: ({ color }) => <Ionicons name="star" size={24} color={color} />,
                        }}
                    />
                }
        </Tabs>
    );
}
