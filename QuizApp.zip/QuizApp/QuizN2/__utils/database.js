import { openDatabaseAsync } from 'expo-sqlite';
import { Alert } from 'react-native';

let db = null;

/**
 * Inicializa ou retorna a instância do banco de dados SQLite.
 * Força a inicialização das tabelas na primeira chamada para não ir de Vasco.
 * @returns {Promise<SQLite.SQLiteDatabase>} 
 */
export const getDb = async () => {
    if (!db) {
        try {

            db = await openDatabaseAsync('quiz.db');
            await initDB(db);
        } catch (error) {
            console.error("Erro ao inicializar o banco de dados:", error);
            // Aviso para caso o Banco de dados for de Vasco
            Alert.alert("Erro Crítico", "Falha ao conectar ou inicializar o banco de dados.");
        }
    }
    return db;
};

/**
 * Cria as tabelas necessárias se elas não existirem para o código funcionar 
 * @param {SQLite.SQLiteDatabase} dbInstance
 */
const initDB = async (dbInstance) => {
   
    await dbInstance.execAsync(`PRAGMA foreign_keys = ON;`);

    //  Cria ás Tabela Temas
    await dbInstance.execAsync(`
        CREATE TABLE IF NOT EXISTS temas (
            id INTEGER PRIMARY KEY AUTOINCREMENT, 
            nome TEXT UNIQUE NOT NULL
        );
    `);

    //  Cria ás Tabela Perguntas
    await dbInstance.execAsync(`
        CREATE TABLE IF NOT EXISTS perguntas (
            id INTEGER PRIMARY KEY AUTOINCREMENT, 
            pergunta TEXT NOT NULL, 
            tema_id INTEGER NOT NULL,
            FOREIGN KEY (tema_id) REFERENCES temas (id) ON DELETE CASCADE
        ); 
    `); 

    // 4. Cria á Tabela Alternativas
    await dbInstance.execAsync(`
        CREATE TABLE IF NOT EXISTS alternativas (
            id INTEGER PRIMARY KEY AUTOINCREMENT, 
            pergunta_id INTEGER NOT NULL, 
            alternativa TEXT NOT NULL, 
            is_correta INTEGER NOT NULL, -- 1 para true, 0 para false
            FOREIGN KEY (pergunta_id) REFERENCES perguntas (id) ON DELETE CASCADE
        );
    `);
};



/**
 * Adiciona um novo tema.
 * @param {string} nome 
 */
export const addTema = async (nome) => {
    if (!nome || nome.trim() === "") throw new Error("Nome do tema não pode ser vazio.");
    const dbInstance = await getDb();
    try {
        await dbInstance.runAsync(`INSERT INTO temas (nome) VALUES (?)`, [nome.trim()]);
    } catch (error) {
        if (error.message.includes("UNIQUE constraint failed")) {
            throw new Error(`O tema '${nome}' já existe.`);
        }
        throw error;
    }
};

/**
 * Adiciona uma nova pergunta 
 * @param {string} pergunta Texto da pergunta.
 * @param {number} tema_id Id do tema associado.
 * @returns {Promise<number>} Id da pergunta inserida.
 */
export const addPergunta = async (pergunta, tema_id) => {
    const dbInstance = await getDb();
    const result = await dbInstance.runAsync(
        `INSERT INTO perguntas (pergunta, tema_id) VALUES (?, ?)`,
        [pergunta, tema_id]
    );
    
    return result.lastInsertRowId;
};

/**
 * Adiciona uma alternativa para uma pergunta.
 * @param {number} pergunta_id Id da pergunta.
 * @param {string} alternativa Texto da alternativa.
 * @param {boolean} is_correta Indica se a alternativa é a resposta correta ou não.
 */
export const addAlternativa = async (pergunta_id, alternativa, is_correta) => {
    const dbInstance = await getDb();
    
    await dbInstance.runAsync(
        `INSERT INTO alternativas (pergunta_id, alternativa, is_correta) VALUES (?, ?, ?)`,
        [pergunta_id, alternativa, is_correta ? 1 : 0]
    );
};



/**
 * Busca todos os temas cadastrados.
 * @returns {Promise<Array<{id: number, nome: string}>>} Lista de temas.
 */
export const getTemas = async () => {
    const dbInstance = await getDb();
    
    return await dbInstance.getAllAsync(`SELECT * FROM temas ORDER BY nome`);
};

/**
 * Conta o número de perguntas para um tema específico.
 * @param {number} tema_id Id do tema.
 * @returns {Promise<number>} Contagem de perguntas.
 */
export const countPerguntasPorTema = async (tema_id) => {
    const dbInstance = await getDb();
    
    const result = await dbInstance.getFirstAsync(`SELECT COUNT(*) as count FROM perguntas WHERE tema_id = ?`, [tema_id]);
    return result ? result.count : 0;
};

/**
 * Busca os dados do quiz (perguntas e alternativas) para um tema.
 * @param {number} tema_id ID do tema.
 * @param {number} limite Número máximo de perguntas.
 * @returns {Promise<Array<Object>>} 
 */
export const getQuizData = async (tema_id, limite) => {
    const dbInstance = await getDb();
    
    // 1. Busca perguntas aleatórias 
    const perguntas = await dbInstance.getAllAsync(
        `SELECT id, pergunta FROM perguntas WHERE tema_id = ? ORDER BY RANDOM() LIMIT ?`,
        [tema_id, limite]
    );

    // 2. Para cada pergunta, busca suas alternativas correspondentes 
    const quizData = [];

    for (const pergunta of perguntas) {
        const alternativas = await dbInstance.getAllAsync(
            `SELECT alternativa, is_correta FROM alternativas WHERE pergunta_id = ?`, 
            [pergunta.id]
        );

        if (alternativas.length !== 4) {
            console.warn(`Pergunta ID ${pergunta.id} ignorada: Encontradas ${alternativas.length} alternativas, mas 4 são necessárias.`);
            continue; // Pula ás perguntas incompletas
        }
        
        let correta = '';
        let erradas = [];

        alternativas.forEach(alt => {
            if (alt.is_correta === 1) {
                correta = alt.alternativa;
            } else {
                erradas.push(alt.alternativa);
            }
        });

        // Garante que temos exatamente 1 correta e 3 alternativas erradas
        if (correta && erradas.length === 3) {
            quizData.push({
                id: pergunta.id,
                pergunta: pergunta.pergunta,
                correta: correta,
                errada1: erradas[0],
                errada2: erradas[1],
                errada3: erradas[2],
            });
        } else {
            console.warn(`Pergunta ID ${pergunta.id} ignorada: Opções inválidas (Corretas: ${correta ? 1 : 0}, Erradas: ${erradas.length}).`);
        }
    }

    return quizData;
};