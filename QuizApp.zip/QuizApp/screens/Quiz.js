import React, { useState, useEffect } from 'react';
import { View, Button, Text } from 'react-native';
import { getTemas } from '../database';

const Quiz = () => {
  const [temas, setTemas] = useState([]);
  const [temaEscolhido, setTemaEscolhido] = useState(null);
  const [quantidade, setQuantidade] = useState(5);

  useEffect(() => {
    const fetchTemas = async () => {
      const temasData = await getTemas();
      setTemas(temasData);
    };
    fetchTemas();
  }, []);

  const handleStartQuiz = () => {
    if (!temaEscolhido) {
      alert('Por favor, escolha um tema.');
      return;
    }
    // Navegar para a tela do quiz com tema e quantidade
  };

  return (
    <View style={{ padding: 20 }}>
      <Text>Escolha um tema</Text>
      {temas.map((tema) => (
        <Button
          key={tema.id}
          title={tema.nome}
          onPress={() => setTemaEscolhido(tema.id)}
        />
      ))}
      <Text>Quantidade de perguntas:</Text>
      <Button title="Começar Quiz" onPress={handleStartQuiz} />
    </View>
  );
};

export default Quiz;
