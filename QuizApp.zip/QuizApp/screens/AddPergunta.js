import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, Picker } from 'react-native';
import { getTemas, addPergunta } from '../database';

const AddPergunta = () => {
  const [temas, setTemas] = useState([]);
  const [pergunta, setPergunta] = useState('');
  const [temaId, setTemaId] = useState('');
  const [respostaCorreta, setRespostaCorreta] = useState('');

  useEffect(() => {
    const fetchTemas = async () => {
      const temasData = await getTemas();
      setTemas(temasData);
    };
    fetchTemas();
  }, []);

  const handleAddPergunta = () => {
    addPergunta(pergunta, temaId, respostaCorreta);
    setPergunta('');
    setRespostaCorreta('');
    alert('Pergunta cadastrada com sucesso!');
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 20, paddingLeft: 10 }}
        placeholder="Digite a pergunta"
        value={pergunta}
        onChangeText={setPergunta}
      />
      <Picker
        selectedValue={temaId}
        onValueChange={setTemaId}
        style={{ height: 40, marginBottom: 20 }}
      >
        {temas.map((tema) => (
          <Picker.Item key={tema.id} label={tema.nome} value={tema.id} />
        ))}
      </Picker>
      <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 20, paddingLeft: 10 }}
        placeholder="Resposta correta"
        value={respostaCorreta}
        onChangeText={setRespostaCorreta}
      />
      <Button title="Cadastrar Pergunta" onPress={handleAddPergunta} />
    </View>
  );
};

export default AddPergunta;
