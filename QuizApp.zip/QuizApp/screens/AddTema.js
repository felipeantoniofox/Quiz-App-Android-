import React, { useState } from 'react';
import { View, TextInput, Button } from 'react-native';
import { addTema } from '../database';

const AddTema = () => {
  const [nomeTema, setNomeTema] = useState('');

  const handleAddTema = () => {
    addTema(nomeTema);
    setNomeTema('');
    alert('Tema cadastrado com sucesso!');
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 20, paddingLeft: 10 }}
        placeholder="Digite o nome do tema"
        value={nomeTema}
        onChangeText={setNomeTema}
      />
      <Button title="Cadastrar Tema" onPress={handleAddTema} />
    </View>
  );
};

export default AddTema;
