import * as SQLite from 'sqlite';
import { openDatabase } from 'expo-sqlite';

const db = openDatabase('quiz.db');

// Função para inicializar o banco de dados
export const initDB = () => {
  db.transaction(tx => {
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS temas (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT);`
    );
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS perguntas (id INTEGER PRIMARY KEY AUTOINCREMENT, pergunta TEXT, tema_id INTEGER, resposta_correta TEXT);`
    );
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS alternativas (id INTEGER PRIMARY KEY AUTOINCREMENT, pergunta_id INTEGER, alternativa TEXT, is_correta BOOLEAN);`
    );
  });
};

// Função para adicionar um tema
export const addTema = (nome) => {
  db.transaction(tx => {
    tx.executeSql(
      `INSERT INTO temas (nome) VALUES (?)`,
      [nome]
    );
  });
};

// Função para adicionar uma pergunta
export const addPergunta = (pergunta, tema_id, resposta_correta) => {
  db.transaction(tx => {
    tx.executeSql(
      `INSERT INTO perguntas (pergunta, tema_id, resposta_correta) VALUES (?, ?, ?)`,
      [pergunta, tema_id, resposta_correta]
    );
  });
};

// Função para adicionar alternativas
export const addAlternativa = (pergunta_id, alternativa, is_correta) => {
  db.transaction(tx => {
    tx.executeSql(
      `INSERT INTO alternativas (pergunta_id, alternativa, is_correta) VALUES (?, ?, ?)`,
      [pergunta_id, alternativa, is_correta ? 1 : 0]
    );
  });
};

// Função para buscar temas
export const getTemas = () => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT * FROM temas`,
        [],
        (_, { rows }) => resolve(rows._array),
        (_, err) => reject(err)
      );
    });
  });
};

// Função para buscar perguntas por tema
export const getPerguntasPorTema = (tema_id) => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT * FROM perguntas WHERE tema_id = ?`,
        [tema_id],
        (_, { rows }) => resolve(rows._array),
        (_, err) => reject(err)
      );
    });
  });
};
